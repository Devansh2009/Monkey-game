var PLAY = 1
var END = 0
var monkey , monkey_running
var bananas ,bananaImage, obstacles, obstacleImage
var FoodGroup, obstacleGroup
var ground, invisibleGround
var score, ground, invisibleGround
var gameState = PLAY


function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
  

}



function setup() {
  monkey = createSprite(80,315,20,20)
  monkey.addAnimation("monkey",monkey_running)
  monkey.scale=0.1
  score = 0
  
  obstaclesGroup = new Group()
  bananasGroup = new Group()
  
  monkey.setCollider("rectangle",0,0,monkey.width-5,monkey.height-5)
  monkey.debug = true
  
  drawSprites();
}


function draw() {
  background("white")
  createCanvas(600,600)
  
  ground = createSprite(400,350,900,10)
  
  if (gameState === PLAY) {
  ground.velocityX = -4
  ground.x = ground.width/2
  //console.log(ground.x)
  
  stroke("white")
  textSize(20)
  fill("white")
  text("Score: "+score,500,50)
  
  stroke("black")
  textSize(20)
  fill("black")
  survivalTime = Math.ceil(frameCount/frameRate())
  text("Survival Time: "+survivalTime,100,50)
  
  if (keyDown("space")&&monkey.y > 311) {
    monkey.velocityY = -10
  }
  
  //console.log(monkey.y)
  
  monkey.velocityY += 0.5
  monkey.collide(ground)
  
  spawnBananas()
  spawnObstacles()
    
  if(monkey.isTouching(obstaclesGroup)) {
    gameState = END
  }
    
  }
  
  if(gameState === END) {
    fill("black")
    textSize(20)
    text("Game over",250,200)
    monkey.velocityY += 0.5
    monkey.collide(ground)
    bananasGroup.setVelocityXEach(0)
    obstaclesGroup.setVelocityXEach(0)
    obstaclesGroup.setLifetimeEach(-1)
    bananasGroup.setLifetimeEach(-1)
  }
  drawSprites();
}

function spawnObstacles() {
  if (frameCount % 300 === 0) {
    obstacles = createSprite(600,310,10,40)
    obstacles.addImage(obstacleImage)
    obstacles.scale = 0.2
    obstacles.velocityX = -(6+3*score/20)
    obstacles.lifetime = 200
    obstaclesGroup.add(obstacles)
  }
}

function spawnBananas() {
  if (frameCount % 80 === 0) {
    bananas = createSprite(600,Math.round(random(120,200)),10,40)
    bananas.addImage(bananaImage)
    bananas.scale = 0.1
    //console.log(bananas.y)
    bananas.velocityX = -(6+3*score/20)
    obstaclesGroup.lifetime = 200
    bananasGroup.add(bananas)
    
  }
}




